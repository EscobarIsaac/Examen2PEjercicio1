import 'dart:io';

class Product {
  String name;
  String description;
  double price;
  File? image;

  Product({
    required this.name,
    required this.description,
    required this.price,
    this.image,
  });
}
