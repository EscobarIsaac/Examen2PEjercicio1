import 'dart:convert';
import 'dart:typed_data';
import 'dart:html' as html;
import 'package:flutter/material.dart';

class Product {
  String name;
  String description;
  double price;
  Uint8List? image;

  Product({
    required this.name,
    required this.description,
    required this.price,
    this.image,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final nameController = TextEditingController();
  final descriptionController = TextEditingController();
  final priceController = TextEditingController();

  Uint8List? imageData;
  String? imageBase64;

  List<Product> products = [];

  void _pickImage() {
    final html.FileUploadInputElement input = html.FileUploadInputElement();
    input.accept = 'image/*';
    input.click();

    input.onChange.listen((event) {
      final file = input.files?.first;
      if (file == null) return;

      final reader = html.FileReader();
      reader.readAsArrayBuffer(file);

      reader.onLoadEnd.listen((event) {
        setState(() {
          imageData = reader.result as Uint8List;
          imageBase64 = base64Encode(imageData!);
        });
      });
    });
  }

  void _openCamera() {
    final html.FileUploadInputElement input = html.FileUploadInputElement();
    input.accept = 'image/*';
    input.setAttribute('capture', 'user');
    input.click();

    input.onChange.listen((event) {
      final file = input.files?.first;
      if (file == null) return;

      final reader = html.FileReader();
      reader.readAsArrayBuffer(file);

      reader.onLoadEnd.listen((event) {
        setState(() {
          imageData = reader.result as Uint8List;
          imageBase64 = base64Encode(imageData!);
        });
      });
    });
  }

  void _saveProduct() {
    final name = nameController.text.trim();
    final description = descriptionController.text.trim();
    final priceText = priceController.text.trim();

    if (name.isEmpty || description.isEmpty || priceText.isEmpty) {
      _showMessage('Por favor, complete todos los campos.');
      return;
    }

    final price = double.tryParse(priceText);
    if (price == null || price <= 0) {
      _showMessage('El precio debe ser un número positivo.');
      return;
    }

    final product = Product(
      name: name,
      description: description,
      price: price,
      image: imageData,
    );

    setState(() {
      products.add(product);
      nameController.clear();
      descriptionController.clear();
      priceController.clear();
      imageData = null;
      imageBase64 = null;
    });
  }

  void _showMessage(String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Atención'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _downloadImage(Uint8List image, String name) {
    final base64 = base64Encode(image);
    final anchor = html.AnchorElement(href: 'data:application/octet-stream;base64,$base64')
    ..download = '$name.png'
    ..click();
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEEFF),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              width: double.infinity,
              color: Colors.purple.shade700,
              child: const Text(
                'Registro de Productos',
                style: TextStyle(fontSize: 24, color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Nombre del producto'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(labelText: 'Descripción'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: priceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Precio'),
            ),
            const SizedBox(height: 16),
            Container(
              height: 150,
              width: double.infinity,
              color: Colors.grey.shade200,
              alignment: Alignment.center,
              child: imageData != null
                  ? Image.memory(imageData!, fit: BoxFit.cover)
                  : const Text('Sin imagen'),
            ),
            const SizedBox(height: 10),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 10,
              children: [
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                  ),
                  onPressed: _pickImage,
                  icon: const Icon(Icons.image),
                  label: const Text('Subir imagen'),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                  ),
                  onPressed: _openCamera,
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('Usar cámara'),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                  ),
                  onPressed: _saveProduct,
                  icon: const Icon(Icons.save),
                  label: const Text('Guardar'),
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Text('Productos registrados', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return ListTile(
                  leading: product.image != null
                      ? Image.memory(product.image!, width: 50, height: 50, fit: BoxFit.cover)
                      : const Icon(Icons.broken_image, size: 50),
                  title: Text(product.name),
                  subtitle: Text('\$${product.price.toStringAsFixed(2)}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.download),
                    onPressed: product.image != null
                        ? () => _downloadImage(product.image!, product.name)
                        : null,
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
