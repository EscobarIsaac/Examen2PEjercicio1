import 'dart:typed_data';
import 'package:flutter/material.dart';

class Product {
  String name;
  String description;
  double price;
  Uint8List? image;

  Product({
    required this.name,
    required this.description,
    required this.price,
    this.image,
  });
}

class ProductViewModel extends ChangeNotifier {
  final List<Product> _products = [];

  List<Product> get products => _products;

  void addProduct(Product product) {
    _products.add(product);
    notifyListeners();
  }

  void deleteProduct(int index) {
    _products.removeAt(index);
    notifyListeners();
  }
}
